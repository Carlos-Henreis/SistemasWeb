<html><head><meta charset="utf-8"></head>
    <body>
        <h2>Obrigado! Seguem as informações digitadas.</h2>
        <h3>Informações de contato</h3>
        <p>Name:<?= $_POST['f_name'] ?> <?= $_POST['l_name'] ?></p>
        <p>Email:<?= $_POST['email'] ?></p>
        <p>OS:<?= $_POST['os'] ?></p>
    </body>
</html><!-- Esta página sera aberta se tudo ocorrer bem -->
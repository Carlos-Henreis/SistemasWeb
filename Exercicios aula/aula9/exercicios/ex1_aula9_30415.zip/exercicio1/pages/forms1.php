<html><head><meta charset="utf-8"></head>
    <body>
        <form action="index2.php" method="post">
            Nome: <input type="text" name="f_name" value=""/> <br/>
            Sobrenome<b>*</b>:<input type="text" name="l_name" value="" /> <br/>
            Email<b>*</b>:<input type="text" name="email" value="" /> <br/>
            Sistema Operacional: <input type="text" name="os" value="" /> <br/><br/>
            <input type="submit" name="submit" value="Submit" /> <input type="reset" />
        </form>
    </body>
</html>
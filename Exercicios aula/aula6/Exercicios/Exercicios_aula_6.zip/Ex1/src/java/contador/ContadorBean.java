package contador;

public class ContadorBean {

    int cont;

    public int getCont() {
        return cont;
    }

    public void aumentaCont() {
        cont++;
    }
}

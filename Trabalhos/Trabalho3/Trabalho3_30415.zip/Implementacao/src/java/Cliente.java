/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Hendrix
 */
public class Cliente {
    
    private int NroConta;
    private String Nome;
    private double Saldo;

    
    public int getNroConta() {
        return NroConta;
    }
    

    public void setNroConta(int NroConta) {
        this.NroConta = NroConta;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    public double getSaldo() {
        return Saldo;
    }

    public void setSaldo(double Saldo) {
        this.Saldo = Saldo;
    }
    
    
    
    
}
